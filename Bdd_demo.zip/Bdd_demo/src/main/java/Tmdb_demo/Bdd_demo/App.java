package Tmdb_demo.Bdd_demo;


import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
						features="src/cucumber/test/list.feature", 
						glue= "",
						tags="@soapui",
						plugin = {"html:report/html/smoke", "json:report/smoke/json-report.json" })

public class App {

}
