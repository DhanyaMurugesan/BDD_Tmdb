package step_definition;
import java.io.IOException;

import org.apache.xmlbeans.XmlException;
import org.junit.Assert;

import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
import com.eviware.soapui.model.iface.Submit.Status;
import com.eviware.soapui.model.testsuite.TestCaseRunContext;
import com.eviware.soapui.model.testsuite.TestCaseRunner;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.model.testsuite.TestStepResult;
import com.eviware.soapui.model.testsuite.TestStepResult.TestStepStatus;
import com.eviware.soapui.support.SoapUIException;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Steps {
	private WsdlProject project;
	private WsdlTestSuite testSuite;
	private WsdlTestCase testCase;
	private TestCaseRunner testRunnerStep;
	private TestStepResult runner;
	@Before("@soapui")
	public void initialise() throws XmlException, IOException, SoapUIException {
		 project=new WsdlProject("E:\\REST-Project-2-soapui-project.xml");
		 testSuite=project.getTestSuiteByName("Verify GET Request");
	}
	@Given("I set the endpoint")
	public void settingEndpoint() {
		 testCase=testSuite.getTestCaseByName("Getting Successful Response");
		WsdlTestStep testStep=testCase.getTestStepByName("Setting endpoint");
		TestCaseRunner testRunnerStep = new com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner((WsdlTestCase) testCase, null);
		TestCaseRunContext testStepContext = new com.eviware.soapui.impl.wsdl.testcase.WsdlTestRunContext(testStep);
		testStep.run(testRunnerStep, testStepContext);
	}
	@When("I perform GET operation for /list with list id 4")
	public void validRequest() {
		WsdlTestStep testStep=testCase.getTestStepByName("Get List");
		 testRunnerStep = new com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner((WsdlTestCase) testCase, null);
		TestCaseRunContext testStepContext = new com.eviware.soapui.impl.wsdl.testcase.WsdlTestRunContext(testStep);
		 runner=testStep.run(testRunnerStep, testStepContext);
	}
	@Then("I should see status code 200")
	public void checkResponse() {
		Assert.assertEquals(TestStepStatus.OK, runner.getStatus());
	}
}