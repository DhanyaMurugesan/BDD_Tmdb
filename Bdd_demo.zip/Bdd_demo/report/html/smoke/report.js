$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/cucumber/test/list.feature");
formatter.feature({
  "name": "Verify GET operation",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Getting Successful Response",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@soapui"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "I set the endpoint",
  "keyword": "Given "
});
formatter.match({
  "location": "step_definition.Steps.settingEndpoint()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I perform GET operation for /list with list id 4",
  "keyword": "When "
});
formatter.match({
  "location": "step_definition.Steps.validRequest()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see status code 200",
  "keyword": "Then "
});
formatter.match({
  "location": "step_definition.Steps.checkResponse()"
});
formatter.result({
  "status": "passed"
});
});